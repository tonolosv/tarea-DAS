﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Foro1
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();

        }

        private void btningresar_Click(object sender, RoutedEventArgs e)
        {

            int edad = Convert.ToInt32(this.txtedad.Text);
            int peso = Convert.ToInt32(this.txtpeso.Text);
            int altura = Convert.ToInt32(this.txtaltura.Text);

            if (edad < 36 && edad > 14)
            {
                if (altura < 146 && altura > 1)
                {
                    if (peso < 121 && peso > 1)
                    {
                        MessageBox.Show("Su edad es: " + edad.ToString() + "  años , su altura es: " + altura.ToString() + " cm y su peso es: " + peso.ToString() + " lb, su estado nutricional se considera ESTABLE");
                    }
                    else
                    {
                        if (peso > 121 && peso < 150)
                        {
                            MessageBox.Show("Su edad es: " + edad.ToString() + " años , su altura es: " + altura.ToString() + " cm y su peso es: " + peso.ToString() + "lb, su estado nutricional ESTA EN LOS NIVELES DE RIESGO");
                        }
                        else
                        {
                            if (peso > 151 && peso < 300)
                            {
                                MessageBox.Show("Su edad es: " + edad.ToString() + " años , su altura es: " + altura.ToString() + " cm y su peso es: " + peso.ToString() + " lb , necesita asesoría nutricional URGENTE");
                            }
                            else
                            {
                                MessageBox.Show("ESTA EN RIESGO SU SALUD, BUSQUE AYUDA");
                            }

                        }
                    }
                }
                else
                {
                    if (altura < 200 && altura > 146)
                    {
                        if (peso < 111 && peso > 1)
                        {
                            MessageBox.Show("Su edad es: " + edad.ToString() + " años, su altura es: " + altura.ToString() + " cm y su peso es: " + peso.ToString() + "lb, su estado nutricional se considera ESTABLE");
                        }
                        else
                        {
                            if (peso > 121 && peso < 150)
                            {
                                MessageBox.Show("Su edad es: " + edad.ToString() + " años, su altura es: " + altura.ToString() + " cm y su peso es: " + peso.ToString() + "lb, su estado nutricional ESTA EN LOS NIVELES DE RIESGO");
                            }
                            else
                            {
                                if (peso > 151 && peso < 300)
                                {
                                    MessageBox.Show("Su edad es: " + edad.ToString() + " años, su altura es: " + altura.ToString() + "cm  y su peso es: " + peso.ToString() + "lb, necesita asesoría nutricional URGENTE");
                                }
                                else
                                {
                                    MessageBox.Show("ESTA EN RIESGO SU SALUD, BUSQUE AYUDA");
                                }
                            }
                        }
                    }
                }

            }

            else
            {

                MessageBox.Show("YA NO ERES JOVEN");




            }

      


        }

        private void btnlimpiar_Click(object sender, RoutedEventArgs e)
        {
            txtaltura.Text = String.Empty;
            txtedad.Text = String.Empty;
            txtpeso.Text = String.Empty;

        }
    }
}





